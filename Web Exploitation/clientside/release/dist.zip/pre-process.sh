docker build -t clientside-builder ./client &&
docker create --name temp-artifact clientside-builder &&
docker cp temp-artifact:/output/ ./ &&
mv ./output ./spawner/bot/dist