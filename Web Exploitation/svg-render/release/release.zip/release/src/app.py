from flask import Flask, render_template, request
from lxml import etree

app = Flask(__name__)


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/out", methods=["POST"])
def out():
    svg = request.form.get("svg")

    if not svg or svg == "":
        return "No SVG provided", 400

    try:
        render, ok = parseValidateSvg(svg)
        if not ok:
            return "Invalid SVG", 400
    except:
        return "Something went wrong", 500

    return render_template("output.html", svg=render)


def parseValidateSvg(svg: str):
    blocklist = [
        "<!doctype",
        "<!entity",
        "[",
        "]",
        "system",
        "flag",
        "file",
        "passwd",
        "etc",
    ]

    for block in blocklist:
        if block in svg.lower():
            print(block)
            return "", False

    parser = etree.XMLParser(resolve_entities=True, no_network=True, load_dtd=False)
    et = etree.fromstring(svg.encode(), parser=parser)

    if not et.tag.endswith("svg"):
        return "", False

    render = etree.tostring(et).decode()

    return render, True


if __name__ == "__main__":
    app.run(port=1337, host="0.0.0.0", debug=False)
